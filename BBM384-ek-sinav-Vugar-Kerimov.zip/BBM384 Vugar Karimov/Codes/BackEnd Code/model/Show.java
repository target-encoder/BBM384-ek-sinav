package com.example.ticketbooking.model;

public class Show {
    public String showName;
    public Long showDate;
    public String showDef;
    public Show(String showName,Long showDate,String showDef){
        this.showName=showName;
        this.showDate=showDate;
        this.showDef=showDef;

    }
    public Show(){

    }
}
