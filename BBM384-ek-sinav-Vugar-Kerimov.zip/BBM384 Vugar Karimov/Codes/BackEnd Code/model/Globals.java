package com.example.ticketbooking.model;

public class Globals {
    public static String username="";
    public static String userstatus="";
    public static String selectedShow="";
    public static String selectedShowDef="";
}
